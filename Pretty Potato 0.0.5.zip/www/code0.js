gdjs.StartScreenCode = {};
gdjs.StartScreenCode.localVariables = [];


gdjs.StartScreenCode.eventsList0 = function(runtimeScene) {

};

gdjs.StartScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.StartScreenCode.eventsList0(runtimeScene);


return;

}

gdjs['StartScreenCode'] = gdjs.StartScreenCode;
